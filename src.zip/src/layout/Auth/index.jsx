import { Outlet } from 'react-router-dom';

// ==============================|| LAYOUT - AUTH ||============================== //

export default function AuthLayout() {
  return (
    <>
      <Outlet />
    </>
  );
}
