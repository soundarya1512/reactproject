import React from 'react';

const PropertyType = () => {
  return (
    <div>
      <h1>Property Type Management</h1>
      <p>Manage different property types here.</p>
    </div>
  );
};

export default PropertyType;