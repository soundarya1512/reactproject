import React from 'react';

const OwnershipType = () => {
  return (
    <div>
      <h1>Ownership Type Management</h1>
      <p>Manage different ownership types here.</p>
    </div>
  );
};

export default OwnershipType;
