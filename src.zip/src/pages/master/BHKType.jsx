import React from 'react';

const BHKType = () => {
  return (
    <div>
      <h1>BHK Type Management</h1>
      <p>Manage different BHK types here.</p>
    </div>
  );
};

export default BHKType;
