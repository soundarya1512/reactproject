import React from 'react';

const DocumentType = () => {
  return (
    <div>
      <h1>Document Type Management</h1>
      <p>Manage different document types here.</p>
    </div>
  );
};

export default DocumentType;