import React from 'react';

const Cities = () => {
  return (
    <div>
      <h1>Cities Management</h1>
      
      <p>Manage all cities here.</p>

    </div>
  );
};

export default Cities;
