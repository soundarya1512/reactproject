
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createRole, getPermissions } from '../../helpers/apiHelper';
import "../../css/Index.css";
import "../../css/form.css";

const AddRoleForm = () => {
  const [name, setName] = useState('');
  const [permissions, setPermissions] = useState({});
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    (async () => {
      try {
        const perms = await getPermissions();
        const grouped = perms.reduce((acc, p) => {
          const cat = p.content_type__model;
          acc[cat] = acc[cat] || [];
          acc[cat].push(p);
          return acc;
        }, {});
        setPermissions(grouped);
      } catch (e) {
        console.error('Fetch perms error', e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const handleCheckboxChange = (cat, code, e) => {
    const checked = e.target.checked;
    setPermissions(prev => ({
      ...prev,
      [cat]: prev[cat].map(p =>
        p.codename === code ? { ...p, checked } : p
      )
    }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const selectedIds = Object.values(permissions)
      .flat()
      .filter(p => p.checked)
      .map(p => p.id);

    const payload = {
      name,
      permissions: selectedIds
    };

    const created = await createRole(payload);
    if (created) navigate('/role');
  };

  return (
    <div className="role-table-container">
      <div className="role-table-header">
        <h2>Add User</h2>
        <button onClick={() => window.history.back()} className="add-role-button">
          Back
        </button>
      </div>

      <form className="form-wrapper" onSubmit={handleSubmit}>
       <p>dsfa</p>

        <div className="form-buttons">
          <button type="submit" className="add-role-button btn-width">Submit</button>
          <button type="button" onClick={() => window.history.back()} className="add-role-button back-btn">
            Back
          </button>
        </div>
      </form>
    </div>
  );
};