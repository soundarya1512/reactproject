import React from 'react'

export default function EditUser() {
  return (
    <div>EditUser</div>
  )
}
