import React from 'react'

function UniqueVisitorCard() {
  return (
    <div>
      <h1>user  details    </h1>
    </div>
  )
}

export default UniqueVisitorCard
